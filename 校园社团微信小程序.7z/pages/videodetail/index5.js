var app = getApp(), util = require("../../utils/util.js");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isLy:false,
    kan:0,
    shoucang:0,
    shetuan:'摄影社',
    biaoti:'摄影社简介',
    stoindex:'index5',
    src:"http://m.qpic.cn/psc?/V51YCgW13u6ec40dXfwm3UXuuV1bX0PP/45NBuzDIW489QBoVep5mcVqroItXAA.RKC8I6ebMtg7ZQCfjgqym9XoEEif9LZiUtOL7pt4CK5uTHe81qv7.9m7lKFT46lOKi8JZtgnOkMc!/b&bo=6QWAAhgHAAMDSR4!&rf=viewer_4",
    dz:'../videodetail/index5'
    ,
    pllist:[],
    lytext:'',
  },
  inputly(e){
    var tmp=e.detail.value;
    console.log(tmp)
    this.setData({lytext:tmp})
  },

  apply(){
    
    var opertime = util.formatTime(new Date());
    var shenqing=wx.getStorageSync('shenqing');
    let shetuan=this.data.shetuan;
    var src=this.data.src;
    console.log(shenqing,opertime)
    let that=this;

    for (var i=0;i<shenqing.length;i++)
    {
      console.log(shenqing[i].userid,app.userinfo.userid,shenqing[i].shetuan==shetuan,shenqing[i].zt)
       if ((shenqing[i].userid==app.userinfo.userid)&&(shenqing[i].shetuan==shetuan)&&(shenqing[i].zt=="待审核"))
       {
        console.log("shenqing[i]",shenqing[i])
        wx.showToast({
          title: '已经申请过了！',
          duration: 1500,
          icon: 'success',
          mask: true,
        })
        return;
        
       }

       if ((shenqing[i].userid==app.userinfo.userid)&&(shenqing[i].shetuan==shetuan)&&(shenqing[i].zt=="审核通过"))
       {
        wx.showToast({
          title: '已加入，无需再申请！',
          duration: 1500,
          icon: 'success',
          mask: true,
        })
        return;
       }
    }


      if (shenqing=='')
      {
         wx.setStorageSync('shenqing', [{userid:app.userinfo.userid,sqsj:opertime,shetuan:shetuan,src:src,avatarUrl:app.userlog.avatarUrl,nickName:app.userlog.nickName,zt:'待审核'}])
        
      }
      else{
       var tmp={userid:app.userinfo.userid,sqsj:opertime,shetuan:shetuan,src:src,avatarUrl:app.userlog.avatarUrl,nickName:app.userlog.nickName,zt:'待审核'};
        shenqing.push(tmp)
        wx.setStorageSync('shenqing', shenqing);

      }

    wx.showToast({
      title: '申请已发送！',
      duration: 1500,
      icon: 'success',
      mask: true,
    })
  },


  liuyanmethod(){

    let isLy=this.data.isLy;
    console.log(isLy)
      this.setData({
        isLy:!isLy
      })
  },

  submitly(){
    var opertime = util.formatTime(new Date());
    let lytext=this.data.lytext;
    let biaoti=this.data.biaoti;
    let src=this.data.src;
    let that=this;

    var tmp=wx.getStorageSync('pinglun')
    console.log('留言内容',tmp)
    var tmp2={lytext:lytext,userid:app.userinfo.userid,opertime:opertime,biaoti:biaoti,src:src,avatarUrl:app.userlog.avatarUrl,nickName:app.userlog.nickName};
    if (tmp=='') {tmp=[];}
    tmp.push(tmp2)
    wx.setStorageSync('pinglun', tmp)
    
    this.setData({
      isLy:false,lytext:''
    })
    that.plsx();
    wx.showToast({
      title: '留言成功！',
      duration: 1500,
      icon: 'success',
      mask: true,
    })
  },

  yishoucang(){
    var stoindex=this.data.stoindex;
    var index=wx.getStorageSync(stoindex);
    console.log(index)
    let kan=this.data.kan;
    let shoucang=this.data.shoucang;
    var shetuan=this.data.shetuan;
    let that=this;
    var src=this.data.src;
    var dz=this.data.dz;
  
        
 

        ////////////////////////////////
        var opertime = util.formatTime(new Date());
        var shoucanglist=wx.getStorageSync('shoucang');
        var biaoti=this.data.biaoti;
     
        console.log('shoucanglist,opertime',shoucanglist,opertime)
   
          if (shoucanglist=='')
          {
             wx.setStorageSync('shoucang', [{userid:app.userinfo.userid,biaoti:biaoti,scsj:opertime,shetuan:shetuan,src:src,dz:dz}])
             shoucang=index.shoucang+1;
             index.shoucang=shoucang;
            that.setData({shoucang:shoucang})
              wx.setStorageSync(stoindex, index)
            
          }
          else{
           var tmp={userid:app.userinfo.userid,biaoti:biaoti,scsj:opertime,shetuan:shetuan,src:src,dz:dz};
           var ysc=false;
           for (var i=0;i<shoucanglist.length;i++)
           {
              if ((shoucanglist[i].userid==app.userinfo.userid)&&(shoucanglist[i].biaoti==biaoti))
              {
                ysc=true;
                console.log(ysc,'ysc有收藏')
              }
           }
           console.log(ysc,'ysc')
           if (ysc==false)
           {
           shoucanglist.push(tmp)
            wx.setStorageSync('shoucang', shoucanglist);


            shoucang=index.shoucang+1;
            index.shoucang=shoucang;
           that.setData({shoucang:shoucang})
             wx.setStorageSync(stoindex, index)
          }
    
          }
////////////////////////////////////////////
    wx.showToast({
      title: '已收藏！',
      duration: 1000,
      icon: 'success',
      mask: true,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  plsx:function(){
      var pllist=this.data.pllist;
       pllist=wx.getStorageSync('pinglun');
       if (pllist!=''){pllist.sort(app.compare("opertime"));}
      this.setData({pllist:pllist})
  },

  onLoad: function (options) {

    var pllist=this.data.pllist;
     pllist=wx.getStorageSync('pinglun');
     if (pllist!=''){pllist.sort(app.compare("opertime"));}
    this.setData({pllist:pllist})


    var stoindex=this.data.stoindex;
    var index=wx.getStorageSync(stoindex);

    console.log(index,stoindex,wx.getStorageSync('shenqing'),wx.getStorageSync('shoucang'))
    let kan=this.data.kan;
    let shoucang=this.data.shoucang;
    let that=this;
      if (index=='')
      {
         wx.setStorageSync(stoindex, {kan:1,shoucang:0})
         that.setData({kan:1})
        
      }
      else{

        kan=index.kan+1;
        shoucang=index.shoucang;
        index.kan=kan;
        console.log('保存的index',index)
        wx.setStorageSync(stoindex, index);
        that.setData({kan:kan,shoucang:shoucang})

      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
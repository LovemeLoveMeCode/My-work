
const app = getApp()

Page({
  data: {
    videoinfolist:[
      {
        url:"../videodetail/index",
        src:"http://r.photo.store.qq.com/psc?/V51YCgW13u6ec40dXfwm3UXuuV1bX0PP/45NBuzDIW489QBoVep5mcVqroItXAA.RKC8I6ebMtg7zCP8e9xJvE3qtA4MwrsyS4r0cgNpimlSzDRO5iHIcdbGYalkivL5Sag8h8x3FGs0!/r",
        videotext:`为了激发学生学习英语的兴趣并丰富广大同学的课余生活,加强英语的学习和交流,提高同学们学习英语的积极性,我校成立英语社团,举行各种活动,激发学生的
        交际兴趣,调动其锻炼口语交际能力的积极性、主动性,使同学们乐于随时随地跟别人
        进行口语交际`
      },
      {
        url:"../videodetail/index2",
        src:"http://r.photo.store.qq.com/psc?/V51YCgW13u6ec40dXfwm3UXuuV1bX0PP/45NBuzDIW489QBoVep5mcTUh1cHU2ietYPQgkj9TkAyVu70gzVHDmVnF9mzpycrDLjwU5mbk8paaTCEldmTBjMDUKTqVzLKrBEpwOizGD4Q!/r",
        videotext:`自从动漫社成立之初的时候，大家怀里揣着对动漫以及各种动漫周边的共同爱好和理想共同努力而创建社团。
        动漫社团的成员们从一开始的拥有共同爱好，最初的仅仅是因为喜欢而聚集在
        一起。从薄弱的基础开始，一起研究和学习动漫，了解动漫人物的性格和特点，直
        至陆续的推出Cosplay节目和作品，到拥有较丰富的社团文化，壮大动漫社团并且逐渐
        从业余走向专业，利用课余时间欣赏动漫，以及进行cosplay的排练等，丰富成员
        们的课余生活，为校园文化增添色彩。社团将不断更新社团的服饰收藏，丰富
        社团物质文化内蕴，以期羽翼丰满时走出校园，走入动漫领域。`
      },
      {
        url:"../videodetail/index3",
        src:"http://r.photo.store.qq.com/psc?/V51YCgW13u6ec40dXfwm3UXuuV1bX0PP/45NBuzDIW489QBoVep5mcVoEGwZ7G7OtBeXI*z81dmlhqeYYB2xsGjhQqday6FbD8i5qZ55E9Qx1.alFTKD5iTX1UvPySEwR4wP.ehANap8!/r",
        videotext:`天文社是天文爱好者组织自愿建立的一个社团。社团在成立后，经常举行观星活动和天文科普活动。社团积极开展校
        内天文科普活动，丰富校园文体娱乐活动形式，积极开展活动，普及天文知识，营造良好的校园文化氛围，
        为校园内爱好天文的同学提供一个交流、学习的平台。`
      },
      {
        url:"../videodetail/index4",
        src:"http://r.photo.store.qq.com/psc?/V51YCgW13u6ec40dXfwm3UXuuV1bX0PP/45NBuzDIW489QBoVep5mcVqroItXAA.RKC8I6ebMtg47r3nNzid2kAKcPP*1f.ug3c8BkhMevoHGSTOUjTw7xy*CRc5stH96fnm5Uw3tcIk!/r",
        videotext:`舞蹈社团的宗旨是“营造艺术氛围、 锻炼良好体魄、 陶冶个人情
        操、 展现自我风采”， 它的成立为学生全面发展、 展现自我提供了一
        个良好的平台。 在校园开展舞蹈社团可以培养学生们的体力、 协调力、
        乐感， 展示小学生蓬勃向上的精神面貌； 同学们可以从舞蹈中汲取灵
        感， 将舞蹈的思维方式， 渗透到自己的生活乃至学习中。 我校开展舞
        蹈社团重在希望通过舞蹈的学习， 培养学生注重加强形体美的展示，
        同时注重内在美。 同时也加强同学们对合作意识的理解， 使同学们之
        间的合作更加默契。`
      },
      {
        url:"../videodetail/index5",
        src:"http://m.qpic.cn/psc?/V51YCgW13u6ec40dXfwm3UXuuV1bX0PP/45NBuzDIW489QBoVep5mcVqroItXAA.RKC8I6ebMtg7ZQCfjgqym9XoEEif9LZiUtOL7pt4CK5uTHe81qv7.9m7lKFT46lOKi8JZtgnOkMc!/b&bo=6QWAAhgHAAMDSR4!&rf=viewer_4",
        videotext:`摄影社是一个以校内喜爱摄影的学生为基础而创建的社团组织，有着
        自己鲜明的个性和特点。摄影社与其它社团最大的不同点在于大部分活动都在室
        外进行。摄影社除了积极参与学校开展的运动会、艺术节等比赛活动的摄影工作
        外，还乐意帮助其它社团拍摄相关的活动照片。摄影社的每一位社员都对摄影抱有浓厚的兴趣，在日常生活中拿起相
        机拍下自己认为美的东西，摄影魅力在于按下快门，记录感动的刹那。`
      }
    ]
  },
 
})

// pages/login/login.js
import Page from '../../common/page'

const app = getApp()

Page({
  data:{
  },

  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {

        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })

        let wxUserInfo = res.userInfo
        wx.setStorageSync('wxUserInfo', wxUserInfo);
        
        app.userlog=res.userInfo;
         wx.reLaunch
        ({
          url: '../myinfo/myinfo',    //跳转账户输入页面
        })
       /*wx.reLaunch
        ({
          url: '../index/index',    //跳转主页面
        })*/
      }
    })
  },

  getUserInfo(e){


    wx.getUserProfile({
      desc: "获取你的昵称、头像、地区及性别",
      success: res => {
        console.log(res)
        let wxUserInfo = res.userInfo;
        wx.setStorageSync('wxUserInfo', wxUserInfo);
      },
    })

      // wx.navigateBack({
      //   delta: 1,
      // })
  
      // wx.showModal({
      //   title: '温馨提示',
      //   content: '将请求您的个人信息',
      //   success(res) {
      //     if (res.confirm) {
      //       wx.getUserProfile({
      //       desc: "获取你的昵称、头像、地区及性别",
      //       success: res => {

      //         request({
      //           name:'login',
      //         }).then(result=>{
      //           console.log(result);
      //           // wx.setStorageSync('userinfo', result.openid);
      //           wx.setStorageSync('token', result.openid);
      //           app.globalData.openid = result.openid
      //           wx.reLaunch({
      //             url: '/pages/index/index',
      //           });
      //         }).catch(err=>{
      //           wx.showToast({
      //             title: err.message||err.errMsg,
      //             icon: 'none',
      //             duration: 2000
      //           })
      //         })
              
      //         console.log(res)
      //         let wxUserInfo = res.userInfo;
      //         wx.setStorageSync('wxUserInfo', wxUserInfo);
      //       },
      //       fail: res => {
      //          //拒绝授权
      //          wx.showToast({
      //           title: '登陆失败',
      //           icon: 'error',
      //         })
      //         return;
      //       }
      //     })} else if (res.cancel) {
      //       wx.showToast({
      //         title: '登陆失败',
      //         icon: 'error',
      //       })
         
      //     }
          
      //   }
        
      // })
  
  

    // console.log("获取info")




    // request({
    //   name:'login',
    // }).then(result=>{
    //   console.log(result);
    //   // wx.setStorageSync('userinfo', result.openid);
    //   wx.setStorageSync('token', result.openid);
    //   app.globalData.openid = result.openid
    //   wx.reLaunch({
    //     url: '/pages/index/index',
    //   });
    // }).catch(err=>{
    //   wx.showToast({
    //     title: err.message||err.errMsg,
    //     icon: 'none',
    //     duration: 2000
    //   })
    // })
  },

  onload(){
    
  }
})

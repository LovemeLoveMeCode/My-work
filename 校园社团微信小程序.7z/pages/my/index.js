// pages/setting/setting.js
import Page from '../../common/page'
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo:{},
    gly:'',
    title: '个人中心',
    itemlist: [{
        itemname: "社团收藏",
        itemicon: 'icon-shoucang',
        bindtapname: 'collecation'
      },
      {
        itemname: "社团申请",
        itemicon: 'icon-shenqing',
        bindtapname: 'applypage'
      }
      , {
        itemname: "待审核",
        itemicon: 'icon-shenqing',
        bindtapname: 'shenhe'
      }
    ]
  },

  //跳转页面
  collecation() {
  /*  wx.showToast({
      title: '暂无收藏',
      icon: 'error',
      duration: 2000
    })*/
     wx.navigateTo({
       url: '../mysc/mysc',
     })
  },

  applypage() {

    wx.navigateTo({
      url: '../mysq/mysq',
    })
    /*
    wx.showToast({
      title: '暂无申请',
      icon: 'error',
      duration: 2000
    })*/
  },
  shenhe() {

    wx.navigateTo({
      url: '../shenhe/shenhe',
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {

  },

  //加载用户信息
  onShow() {
  
     this.setData({userinfo:app.userlog,gly:app.userinfo.userlx})
    
     console.log()
  },


  //退出登录
  handleClick: function (res) {
    // wx.clearStorageSync();  //清除数据
    wx.reLaunch({
      url: '/pages/login/index'
    });
  }
})
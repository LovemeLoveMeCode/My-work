var app = getApp(), util = require("../../utils/util.js");

Page({
    data: {
        date: "2016-09-01",
        userlog:{},
        userInfo:{userid:'',userpass:''}
    },
    bindDateChange: function(e) {
        this.setData({
            date: e.detail.value
        });
    },
    dw: function() {
        var t = this;
        wx.chooseLocation({
            success: function(e) {
                console.log(e), t.setData({
                    weizhi: e.address,
                    jwd: e.latitude + "," + e.longitude
                });
            },
            fail: function() {
                wx.showModal({
                    title: "警告",
                    content: "您点击了拒绝地理位置授权,无法正常使用功能，点击确定重新获取授权。",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && wx.openSetting({
                            success: function(e) {
                                e.authSetting["scope.userLocation"], t.dw();
                            },
                            fail: function(e) {}
                        });
                    }
                });
            }
        });
    },

    inputzh: function(e) {
        console.log(e.detail.value);
        this.data.userInfo.userid=e.detail.value;
    },
    inputmm: function(e) {
        console.log(e.detail.value);
        this.data.userInfo.userpass=e.detail.value;
    },


    formSubmit: function(e) {
     
        let userInfo=this.data.userInfo;
        let that=this;
   
        console.log(userInfo,'userinfo')
        wx.showLoading({
           title: '登陆中...',
         })
          
        if (userInfo.userid=='')
        {
   
           wx.hideLoading();
           
           wx.showModal({
   
               title: '没有输入帐号！',
               showCancel: false,
               confirmText: "知道了",
   
               success: function (res) {
                 if (res.confirm) {
                   return;
                 }  else {                 
                        }
               }
             })
   } else
   {
          for (var i=0;i<app.userlist.length;i++)
          {
              if ((app.userlist[i].userid==userInfo.userid)&&(app.userlist[i].userpass==userInfo.userpass))
              {
                  app.userinfo=app.userlist[i]
                wx.reLaunch
                ({
                  url: '../index/index',    //跳转主页面
                })
                wx.showToast({
                  title: '登陆成功！',
                })
                return;
              }

          }
          wx.hideLoading();
          wx.showModal({ 
            title: '帐号或密码有误！',
            showCancel: false,
            confirmText: "知道了",

            success: function (res) {
              if (res.confirm) {
                return;
              }  else {                 
                     }
            }
          })

   }
    },
    onLoad: function(e) {
      let userlog=this.data.userlog;
      console.log(app.userlog)
      this.setData({userlog:app.userlog})
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
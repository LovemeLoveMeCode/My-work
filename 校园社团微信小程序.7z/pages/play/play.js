// 创建一个音频组件
const myAudio = wx.createInnerAudioContext()
Page({
  data: {
    isPlay: false,
    audioSrc: 'http://www.bwdz.cn/1.mp3'
  },
onLoad(){
  let isPlay = this.data.isPlay
  myAudio.src=this.data.audioSrc
  myAudio.play()
},
  playAudio(){
    let isPlay = this.data.isPlay
    // console.log(isPlay)
    // 如果当前没有播放音频，则点击之后开始播放音频
    if(!isPlay){
      myAudio.src=this.data.audioSrc
      myAudio.play()
    }else{
      myAudio.pause();
    }
    this.setData({
      isPlay: !isPlay
    })
  },
})
// pages/detail/detail.js
const app = getApp()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        xzcp:[],
        star: 0,
        starMap: [
            '非常差',
            '差',
            '一般',
            '好',
            '非常好',
          ],
        commentList: [],
        info: {
            username: '',
            imgUrl: '',
            content: '',
            time: ''
        },
        commentMsg: '',
        isFriend: false
    },

    /**
     * 生命周期函数--监听页面加载
     */

  
    gotoDetail(e){
        var dz = e.currentTarget.dataset.dz

wx.navigateTo({
          url: dz,
        })


    }  ,
    onLoad(options) {
 

        let xzcp=this.data.xzcp;
         let that=this;
        var tmp=wx.getStorageSync('shoucang')

        
    for (var i=0;i<tmp.length;i++)
    {
   
       if (tmp[i].userid==app.userinfo.userid)
       {
         xzcp.push(tmp[i])

       }

    }
        this.setData({xzcp:xzcp})
        console.log(xzcp)
 
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})
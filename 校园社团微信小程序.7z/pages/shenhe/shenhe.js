// pages/detail/detail.js
const app = getApp()

Page({

    /**
     * 页面的初始数据
     */
    data: {
        xzcp:[],
        star: 0,
        starMap: [
            '非常差',
            '差',
            '一般',
            '好',
            '非常好',
          ],
        commentList: [],
        info: {
            username: '',
            imgUrl: '',
            content: '',
            time: ''
        },
        commentMsg: '',
        isFriend: false
    },

    /**
     * 生命周期函数--监听页面加载
     */

  tongguo(e){
    var item = e.currentTarget.dataset.item;
    var tmp=wx.getStorageSync('shenqing')
let that=this;
        console.log(tmp,'tmp')
    for (var i=0;i<tmp.length;i++)
    {
   
        console.log(tmp[i],item,'对比')
       if ((tmp[i].userid==item.userid)&&(tmp[i].shetuan==item.shetuan)&&(tmp[i].sqsj==item.sqsj))
       {

        console.log(tmp[i],item,'进来了')
         item.zt="审核通过";
         tmp[i]=item;
         wx.setStorageSync('shenqing', tmp);
         that.onLoad();
       }

    }

  },
    gotoDetail(e){
        var dz = e.currentTarget.dataset.dz

          wx.navigateTo({
          url: dz,
        })


    }  ,
    onLoad(options) {
 

        let xzcp=this.data.xzcp;
         let that=this;
        var tmp=wx.getStorageSync('shenqing')

        xzcp=[];
    for (var i=0;i<tmp.length;i++)
    {
   
       if ((tmp[i].shetuan==app.userinfo.userst)&&(tmp[i].zt=="待审核"))
       {
         xzcp.push(tmp[i])

       }

    }
        this.setData({xzcp:xzcp})
        console.log(xzcp)
 
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})
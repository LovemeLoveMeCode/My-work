// app.js
App({
  compare: function (property) {
    return function (a, b) {
      var value1 = a[property];
      var value2 = b[property];
      return value2 - value1;
    }
 
  },
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
  globalData: {
    userInfo: null
  },
  userinfo:null,
  userlog:null,
  userlist:[
    {userid:'zhang',usermc:'路人甲',userpass:'123456',userlx:'普通用户',userst:''}
  ,{userid:'yingyu',usermc:'TOM',userpass:'123456',userlx:'管理员',userst:'英语社'}
  ,{userid:'dongman',usermc:'机器猫',userpass:'123456',userlx:'管理员',userst:'动漫社'}
  ,{userid:'tianwen',usermc:'海王星',userpass:'123456',userlx:'管理员',userst:'天文社'}
  ,{userid:'wudao',usermc:'杰克逊',userpass:'123456',userlx:'管理员',userst:'舞蹈社'}
  ,{userid:'sheying',usermc:'佳能',userpass:'123456',userlx:'管理员',userst:'摄影社'}
]
})
